from __future__ import annotations
import enum
from enum import Enum
from typing import Union, List, Any, Optional
from functools import reduce
import operator as _op
from typing import Callable
import re
import unicodedata


class CommonParser:
    
    @staticmethod
    def normalize_text(s: str, case_insensitive: bool = False, ascii_fold: bool = True) -> str:
        s = str(s)
        if not s:
            return s
        
        _SMART_PUNCT_MAP = str.maketrans({
            "\u2018": "'",  # left single quote
            "\u2019": "'",  # right single quote
            "\u201C": '"',  # left double quote
            "\u201D": '"',  # right double quote
            "\u00A0": " ",  # non-breaking space
            "\u200B": "",   # zero-width space
            "\u200C": "",   # zero-width non-joiner
            "\u200D": "",   # zero-width joiner
            "\uFEFF": "",   # BOM / zero-width no-break
        })

        # 1) Unicode compatibility normalization
        if ascii_fold: # fold Accents, Ligatures, Fancy Unicode letters, Circled numbers.. E.G: café → cafe
            s = unicodedata.normalize("NFKD", s)
            s = "".join(c for c in s if not unicodedata.combining(c))
        else:
            s = unicodedata.normalize("NFKC", s)

        # 2) Smart punctuation + invisibles
        s = s.translate(_SMART_PUNCT_MAP)

        # 3) Whitespace normalization
        s = re.sub(r"\s+", " ", s).strip()

        # 4) Unicode-safe case normalization
        if case_insensitive:
            s = s.casefold()
        return s

    
    def _safe_cast_to_bool(self, value) -> bool:
        
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            if value.lower() in ["true", "false"]:
                return value.lower() == "true"
            else:
                return self.normalize_text(value)
            
        if isinstance(value, (int, float)):
            return value
        
        return False
    

    def _access_nested_value(self, variable_dump, name):
        """
        Access nested values in a dictionary using dot notation.
        Handles keys like 'api_variablebe40.response_body.amount'
        """
        keys = name.split('.')
        value = variable_dump

        for key in keys:
            while '[' in key and ']' in key:
                # Handle nested list indexing
                base_key, index = key.split('[', 1)
                index = int(index.split(']')[0])
                value = value[base_key] if base_key else value
                value = value[index]
                key = key[key.index(']') + 1:]  # Move to the next part of the key

            if key:  # Handle any remaining dictionary key
                value = value[key]
        return value

class ResolvedCondition:
    def __init__(self, left_operand: str, operator: PossibleCondition, right_operand: str):
        self.left_operand = left_operand
        self.operator = operator
        self.right_operand = right_operand
        
    
    def to_dict(self):
        return {
            "left_operand": self.left_operand,
            "operator": self.operator.value,
            "right_operand": self.right_operand,
        }
    
    @classmethod
    def from_string(cls, condition: str):
        for op in PossibleCondition:
            if op.value in condition:
                left_operand, right_operand = condition.split(op.value, 1)

                return cls(
                    left_operand.strip(),
                    op,
                    right_operand.strip()
                )

        raise ValueError("Invalid condition string")

    
    
    @classmethod
    def from_json(cls, json_data):
        return cls(
            left_operand = json_data.get('left_operand', ''),
            operator = PossibleCondition(json_data.get('operator', '')),
            right_operand = json_data.get('right_operand', ''),
        )
        
    @classmethod
    def create_string_from_condition(cls, conditions: list[ResolvedCondition], connectors: list[ConcatenationOperator]):
        condition_string = ""
        for idx, condition in enumerate(conditions):
            condition_string += str(condition)
            if idx < len(connectors):
                condition_string += connectors[idx].value
        return condition_string
    
    
    def __str__(self):
        return f"{self.left_operand} {self.operator.value} {self.right_operand}"
    
    def __eq__(self, other):
        if not isinstance(other, ResolvedCondition):
            return False
        return self.left_operand == other.left_operand and self.operator == other.operator and self.right_operand == other.right_operand

class Condition(CommonParser):
    def __init__(self, conditions: list[ResolvedCondition], connectors: list[ConcatenationOperator]):
        self.connectors = connectors
        self.conditions = conditions
        
    def _resolve_placeholder(self, s: str, variables: dict, get_variable_value: Callable, *args, **kwargs):
        if get_variable_value is not None and isinstance(get_variable_value, Callable):
            result = get_variable_value(s, variables, *args, **kwargs)
            return result, {s: result}
        s = s.strip()
        if s.startswith("{{") and s.endswith("}}"):
            key = s[2:-2].strip()
            try:
                result = self._access_nested_value(variables, key)
                return result, {key: result}
            except (KeyError, TypeError, IndexError) as e:
                raise KeyError(f"Variable '{key}' not found in variables: {e}")
        if s.startswith("${") and s.endswith("}"):
            key = s[2:-1].strip()
            try:
                result = self._access_nested_value(variables, key)
                return result, {key: result}
            except (KeyError, TypeError, IndexError) as e:
                raise KeyError(f"Variable '{key}' not found in variables: {e}")
        return s, {}  # not a placeholder

    def _clean_string(self, s: str) -> str:
        if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")):
            return s[1:-1]
        return s
    
    def _is_numeric(self, val):
        if isinstance(val, (int, float)):
            return True
        if isinstance(val, str):
            val = val.strip()
            if val.isdigit():
                return True
            try:
                float(val)
                return True
            except ValueError:
                return False
        return False

    def _to_numeric(self, val):
        # Already numeric
        if isinstance(val, (int, float)):
            return val

        if isinstance(val, str):
            val = val.strip()

            # Try int first (so "10" becomes int, not float)
            try:
                intval = int(val)
                return intval
            except ValueError:
                pass

            # Try float
            try:
                floatval = float(val)
                return floatval
            except ValueError:
                return None

        return None


    def _is_typecast_required(self, left_operand: Any, right_operand: Any) -> tuple[Any, Any]:
        """
        Check if type casting is required between operands and perform it if needed.
        If one operand is a string and the other is a number, attempt to cast the string to a number.
        Returns a tuple of (left_operand, right_operand) with appropriate type casting applied.
        """
        # Check if one is a string and the other is a number
        left_is_str = isinstance(left_operand, str)
        right_is_str = isinstance(right_operand, str)
        left_is_numeric = self._is_numeric(left_operand)
        right_is_numeric = self._is_numeric(right_operand)

        if left_is_numeric and right_is_numeric:
            return self._to_numeric(left_operand), self._to_numeric(right_operand)
        
        if left_is_str:
            left_operand = self._clean_string(left_operand)
        if right_is_str:
            right_operand = self._clean_string(right_operand)
            
        # If both are strings or both are numeric, no casting needed
        if (left_is_str and right_is_str) or (left_is_numeric and right_is_numeric):
            return left_operand, right_operand
        
        # If left is string and right is numeric, try to cast left to number
        if left_is_str and right_is_numeric:
            try:
                # Try to cast to int first if it's a whole number, otherwise float
                casted_left = float(left_operand.strip())
                # If it's a whole number and right is int, cast to int
                if isinstance(right_operand, int) and casted_left.is_integer():
                    return int(casted_left), right_operand
                return casted_left, right_operand
            except (ValueError, AttributeError):
                # If casting fails, return original operands
                return left_operand, right_operand
        
        # If right is string and left is numeric, try to cast right to number
        if right_is_str and left_is_numeric:
            try:
                # Try to cast to int first if it's a whole number, otherwise float
                casted_right = float(right_operand.strip())
                # If it's a whole number and left is int, cast to int
                if isinstance(left_operand, int) and casted_right.is_integer():
                    return left_operand, int(casted_right)
                return left_operand, casted_right
            except (ValueError, AttributeError):
                # If casting fails, return original operands
                return left_operand, right_operand
        
        # No casting needed or possible
        return left_operand, right_operand
    
    def _eval_condition(self, operator: PossibleCondition, left_operand: Any, right_operand: Any)->bool:
        
        # Apply type casting if needed before evaluation
        left_operand, right_operand = self._is_typecast_required(left_operand, right_operand)
        
        if operator == PossibleCondition.EQUALS:
            return left_operand == right_operand or (self._safe_cast_to_bool(left_operand) == self._safe_cast_to_bool(right_operand))
        if operator == PossibleCondition.NOT_EQUALS:
            return left_operand != right_operand and not (self._safe_cast_to_bool(left_operand) == self._safe_cast_to_bool(right_operand))
        if operator == PossibleCondition.GREATER_THAN:
            return left_operand > right_operand
        if operator == PossibleCondition.LESS_THAN:
            return left_operand < right_operand
        if operator == PossibleCondition.GREATER_THAN_OR_EQUALS:
            return left_operand >= right_operand
        if operator == PossibleCondition.LESS_THAN_OR_EQUALS:
            return left_operand <= right_operand
        if operator == PossibleCondition.CONTAINS:
            return CommonParser.normalize_text(right_operand) in CommonParser.normalize_text(left_operand)
        if operator == PossibleCondition.NOT_CONTAINS:
            return CommonParser.normalize_text(right_operand) not in CommonParser.normalize_text(left_operand)
        if operator == PossibleCondition.STARTS_WITH:
            return CommonParser.normalize_text(left_operand).startswith(CommonParser.normalize_text(right_operand))
        if operator == PossibleCondition.ENDS_WITH:
            return CommonParser.normalize_text(left_operand).endswith(CommonParser.normalize_text(right_operand))
        raise ValueError(f"Unsupported condition: {operator}")
    
    def evaluate(self, variables: dict, get_variable_value: Callable, *args, **kwargs)->(bool, dict):
        used_variables = {}
        results = []
        for condition in self.conditions:
            _used_variables = {}
            _left_operand, left_operand_variables = self._resolve_placeholder(condition.left_operand, variables, get_variable_value, *args, **kwargs)
            _right_operand, right_operand_variables = self._resolve_placeholder(condition.right_operand, variables, get_variable_value, *args, **kwargs)
            result = self._eval_condition(condition.operator, _left_operand, _right_operand)
            _used_variables.update(left_operand_variables)
            _used_variables.update(right_operand_variables)
            used_variables.update(_used_variables)
            results.append(result)
        
        # If there are no connectors, return the single result
        if not self.connectors:
            return results[0], used_variables
        
        # Otherwise, combine results with connectors
        final_result = results[0]
        for idx, connector in enumerate(self.connectors):
            if connector == ConcatenationOperator.AND:
                final_result = final_result and results[idx + 1]
            elif connector == ConcatenationOperator.OR:
                final_result = final_result or results[idx + 1]
            else:
                raise ValueError(f"Unsupported connector: {connector}")
        return final_result, used_variables
    
    def to_dict(self):
        return {
            "connectors": [connector.value for connector in self.connectors],
            "conditions": [condition.to_dict() for condition in self.conditions],
        }
        
class PossibleCondition(enum.Enum):
    EQUALS = "=="
    NOT_EQUALS = "!="
    GREATER_THAN = ">"
    LESS_THAN = "<"
    GREATER_THAN_OR_EQUALS = ">="
    LESS_THAN_OR_EQUALS = "<="
    CONTAINS = "contains"
    NOT_CONTAINS = "not_contains"
    STARTS_WITH = "starts_with"
    ENDS_WITH = "ends_with"
    # add default value for all the operators
    
    @classmethod
    def _missing_(cls, value):
        # incase of invalid operator, return the default value
        return cls.EQUALS
    
    def __str__(self):
        return self.value
    
    def __eq__(self, other):
        if not isinstance(other, PossibleCondition):
            return False
        return self.value == other.value
    


class MathOperationOperator(enum.Enum):
    #add|subtract|multiply|divide|mod|pow|negate|abs
    ADD = "add"
    SUBTRACT = "subtract"
    MULTIPLY = "multiply"
    DIVIDE = "divide"
    MODULUS = "mod"
    POWER = "pow"
    NEGATE = "negate"
    ABS = "abs"
        
    

class Mathmatic:
    def __init__(self, operator: MathOperationOperator, operands: list[Union[str, Mathmatic]]): # operator can be int (in form of string) or placeholder {{}} / ${} in form of string or MathOperation object
        self.operator = operator
        self.operands = operands
        # add validation check if operator is subtract or divide, then the length of operands should be 2
        if self.operator in [MathOperationOperator.SUBTRACT, MathOperationOperator.DIVIDE, MathOperationOperator.MODULUS]:
            if len(self.operands) != 2:
                raise ValueError("Subtract and Divide operators require exactly 2 operands")
        # add validation check if operator is negate, then the length of operands should be 1
        if self.operator == MathOperationOperator.NEGATE:
            if len(self.operands) != 1:
                raise ValueError("Negate operator require exactly 1 operand")
        # add validation check if operator is abs, then the length of operands should be 1
        if self.operator == MathOperationOperator.ABS:
            if len(self.operands) != 1:
                raise ValueError("Abs operator require exactly 1 operand")
        
    
    def to_dict(self):
        return {
            "operator": self.operator.value,
            "operands": [operand.to_dict() if isinstance(operand, Mathmatic) else operand for operand in self.operands],
        }
    
    
    def update_variable_scope(self, new_variable_reference: str, old_variable_reference: str, *args, **kwargs):
        # update the variables referenced in expression tree
        for idx, operand in enumerate(self.operands):
            if isinstance(operand, Mathmatic):
                operand.update_variable_scope(new_variable_reference, old_variable_reference)
            else:
                if isinstance(operand, str) and old_variable_reference in operand:
                    self.operands[idx] = operand.replace(old_variable_reference, new_variable_reference)

    def _resolve_placeholder(self, s: str, variables: dict, get_variable_value: Callable, *args, **kwargs):
        if get_variable_value is not None and isinstance(get_variable_value, Callable):
            return get_variable_value(s, variables, *args, **kwargs)
        s = s.strip()
        if s.startswith("{{") and s.endswith("}}"):
            key = s[2:-2].strip()
            try:
                return self._access_nested_value(variables, key)
            except (KeyError, TypeError, IndexError) as e:
                raise KeyError(f"Variable '{key}' not found in variables: {e}")
        if s.startswith("${") and s.endswith("}"):
            key = s[2:-1].strip()
            try:
                return self._access_nested_value(variables, key)
            except (KeyError, TypeError, IndexError) as e:
                raise KeyError(f"Variable '{key}' not found in variables: {e}")
        return s  # not a placeholder

    def _resolve_placeholder_with_variables(self, s: str, variables: dict, get_variable_value: Callable, *args, **kwargs):
        if get_variable_value is not None and isinstance(get_variable_value, Callable):
            result = get_variable_value(s, variables, *args, **kwargs)
            return result, {s: result}
        s = s.strip()
        if s.startswith("{{") and s.endswith("}}"):
            key = s[2:-2].strip()
            try:
                result = self._access_nested_value(variables, key)
                return result, {key: result}
            except (KeyError, TypeError, IndexError) as e:
                raise KeyError(f"Variable '{key}' not found in variables: {e}")
        if s.startswith("${") and s.endswith("}"):
            key = s[2:-1].strip()
            try:
                result = self._access_nested_value(variables, key)
                return result, {key: result}
            except (KeyError, TypeError, IndexError) as e:
                raise KeyError(f"Variable '{key}' not found in variables: {e}")
        return s, {}  # not a placeholder

    def _access_nested_value(self, variable_dump, name):
        """
        Access nested values in a dictionary using dot notation.
        Handles keys like 'api_variablebe40.response_body.amount'
        """
        keys = name.split('.')
        value = variable_dump

        for key in keys:
            while '[' in key and ']' in key:
                # Handle nested list indexing
                base_key, index = key.split('[', 1)
                index = int(index.split(']')[0])
                value = value[base_key] if base_key else value
                value = value[index]
                key = key[key.index(']') + 1:]  # Move to the next part of the key

            if key:  # Handle any remaining dictionary key
                value = value[key]
        return value

    def _as_number(self, value):
        # Convert value to float if possible; raise if not numeric
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            # Try to parse numeric string
            try:
                return float(value.strip())
            except Exception:
                raise ValueError(f"Non-numeric operand encountered: {value!r}")
        raise ValueError(f"Unsupported operand type: {type(value).__name__}")

    def evaluate(self, variables: dict, get_variable_value: Callable, *args, **kwargs)->(float, dict):
        # Resolve all operands to numbers (recursively for nested operations, and resolving placeholders)
        resolved = []
        used_variables = {}
        
        for operand in self.operands:
            if isinstance(operand, Mathmatic):
                result, child_variables = operand.evaluate(variables, get_variable_value, *args, **kwargs)
                resolved.append(self._as_number(result))
                used_variables.update(child_variables)
            else:
                # Resolve placeholders if it's a string
                if isinstance(operand, str):
                    operand_value, operand_variables = self._resolve_placeholder_with_variables(operand, variables, get_variable_value, *args, **kwargs)
                    used_variables.update(operand_variables)
                    resolved.append(self._as_number(operand_value))
                else:
                    resolved.append(self._as_number(operand))

        if self.operator == MathOperationOperator.ADD:
            return sum(resolved), used_variables
        elif self.operator == MathOperationOperator.SUBTRACT:
            return resolved[0] - resolved[1], used_variables
        elif self.operator == MathOperationOperator.MULTIPLY:
            return reduce(_op.mul, resolved, 1.0), used_variables
        elif self.operator == MathOperationOperator.DIVIDE:
            if resolved[1] == 0:
                raise ZeroDivisionError("Division by zero")
            return resolved[0] / resolved[1], used_variables
        elif self.operator == MathOperationOperator.MODULUS:
            if resolved[1] == 0:
                raise ZeroDivisionError("Modulo by zero")
            return resolved[0] % resolved[1], used_variables
        elif self.operator == MathOperationOperator.POWER:
            return resolved[0] ** resolved[1], used_variables
        elif self.operator == MathOperationOperator.NEGATE:
            return -resolved[0], used_variables
        elif self.operator == MathOperationOperator.ABS:
            return abs(resolved[0]), used_variables
        else:
            raise ValueError(f"Unsupported operator: {self.operator}")
    
    
    @classmethod
    def from_json(cls, json_data):
        """
        Create a MathOperation from JSON data.
        Handles nested operations by recursively creating MathOperation objects.
        """
        operator = MathOperationOperator(json_data.get('operator', 'add')) 
        operands = []
        
        for operand in json_data.get('operands', []):
            if isinstance(operand, dict) and 'operator' in operand:
                # This is a nested MathOperation
                operands.append(cls.from_json(operand))
            else:
                # This is a simple operand (string, number, etc.)
                operands.append(operand)
        
        return cls(operator=operator, operands=operands)
    
    
    

class AssertionCondition(enum.Enum):
    #"equals|not_equals|greater_than|less_than|greater_than_or_equal|less_than_or_equal|starts_with|ends_with|contains|length_equals|type_equals|json_key_exists|json_keys_count|json_array_length_equals|json_array_contains|json_value_equals",
    EQUALS = "equals"
    NOT_EQUALS = "not_equals"
    GREATER_THAN = "greater_than"
    LESS_THAN = "less_than"
    GREATER_THAN_OR_EQUALS = "greater_than_or_equal"
    LESS_THAN_OR_EQUALS = "less_than_or_equal"
    STARTS_WITH = "start_with"
    ENDS_WITH = "end_with"
    CONTAINS = "contains"
    NOT_CONTAINS = "not_contains"
    LENGTH_EQUALS = "length_equals"
    TYPE_EQUALS = "type_equals"
    JSON_KEY_EXISTS = "json_key_exists"
    JSON_KEYS_COUNT = "json_keys_count"
    JSON_ARRAY_LENGTH_EQUALS = "json_array_length_equals"
    JSON_ARRAY_CONTAINS = "json_array_contains"
    JSON_VALUE_EQUALS = "json_value_equals"
    # add default value for all the operators
    @classmethod
    def _missing_(cls, value):
        # incase of invalid operator, return the default value
        return cls.EQUALS
    
    def __str__(self):
        return self.value
    
    def __eq__(self, other):
        if not isinstance(other, AssertionCondition):
            return False
        return self.value == other.value
    
class ConcatenationOperator(enum.Enum):
    AND = "AND"
    OR = "OR"


class Assertion(CommonParser):
    def __init__(
        self,
        assertion_operator: Union[AssertionCondition, List[AssertionCondition], ConcatenationOperator] = None,  # leaf: equals, [equals], or group: AND/OR
        assertion_operands: Optional[List[ConcatenationOperator]] = None,   # group: [AND] or [OR] (usually one)
        left_operand: Any = None,
        right_operand: Any = None,
        operands: Optional[List["Assertion"]] = None,                       # children for logical groups
        operator: Union[AssertionCondition, ConcatenationOperator] = None   # alias for assertion_operator for backward compatibility
    ):
        # Handle backward compatibility with 'operator' parameter
        if operator is not None and assertion_operator is None:
            assertion_operator = operator
            
        # Handle single operator vs list of operators
        if isinstance(assertion_operator, AssertionCondition):
            self.assertion_operator = [assertion_operator]
            self.assertion_operands = assertion_operands or []
        elif isinstance(assertion_operator, ConcatenationOperator):
            self.assertion_operator = []
            self.assertion_operands = [assertion_operator]
        elif isinstance(assertion_operator, list):
            self.assertion_operator = assertion_operator
            self.assertion_operands = assertion_operands or []
        else:
            self.assertion_operator = []
            self.assertion_operands = assertion_operands or []
        self.left_operand = left_operand
        self.right_operand = right_operand
        self.operands = operands or []   # if non-empty, this node is a logical group


    def update_variable_scope(self, new_variable_reference: str, old_variable_reference: str, *args, **kwargs):
        # update the variables referenced in expression tree
        if isinstance(self.left_operand, str):
            self.left_operand = self.left_operand.replace(old_variable_reference, new_variable_reference)
        if isinstance(self.right_operand, str):
            self.right_operand = self.right_operand.replace(old_variable_reference, new_variable_reference)
        for operand in self.operands:
            operand.update_variable_scope(new_variable_reference, old_variable_reference)

    # ---------- helpers ----------
    def _resolve(self, value, variables: dict, get_variable_value: Callable, *args, **kwargs):
        if isinstance(value, str):
            if isinstance(get_variable_value, Callable) and get_variable_value is not None:
                s = get_variable_value(value, variables, *args, **kwargs)
                try:
                    return float(s), {value: s}
                except Exception:
                    return s, {value: s}
            s = value.strip()
            if s.startswith("{{") and s.endswith("}}"):
                key = s[2:-2].strip()
                resolved_value = self._access_nested_value(variables, key)
                return resolved_value, {key: resolved_value}
            if s.startswith("${") and s.endswith("}"):
                key = s[2:-1].strip()
                resolved_value = self._access_nested_value(variables, key)
                return resolved_value, {key: resolved_value}
            # best-effort numeric parse; otherwise leave as string
            try:
                return float(s), {}
            except Exception:
                return s, {}
        return value, {}

        
    def _eval_leaf_condition(self, cond: AssertionCondition, left, right) -> bool:
        if cond == AssertionCondition.EQUALS:
            return left == right or (self._safe_cast_to_bool(left) == self._safe_cast_to_bool(right))
        if cond == AssertionCondition.NOT_EQUALS:
            return left != right and not (self._safe_cast_to_bool(left) == self._safe_cast_to_bool(right))
        if cond == AssertionCondition.GREATER_THAN:
            return left > right
        if cond == AssertionCondition.LESS_THAN:
            return left < right
        if cond == AssertionCondition.GREATER_THAN_OR_EQUALS:
            return left >= right
        if cond == AssertionCondition.LESS_THAN_OR_EQUALS:
            return left <= right
        if cond == AssertionCondition.CONTAINS:
            return CommonParser.normalize_text(right) in CommonParser.normalize_text(left)
        if cond == AssertionCondition.NOT_CONTAINS:
            return CommonParser.normalize_text(right) not in CommonParser.normalize_text(left)
        if cond == AssertionCondition.STARTS_WITH:  # note: enum value is "start_with"
            return CommonParser.normalize_text(left).startswith(CommonParser.normalize_text(right))
        if cond == AssertionCondition.ENDS_WITH:    # enum value is "end_with"
            return CommonParser.normalize_text(left).endswith(CommonParser.normalize_text(right))
        if cond == AssertionCondition.LENGTH_EQUALS:
            return len(left) == int(right)
        if cond == AssertionCondition.TYPE_EQUALS:
            return type(left).__name__ == str(right)
        if cond == AssertionCondition.JSON_KEY_EXISTS:
            return isinstance(left, dict) and str(right) in left
        if cond == AssertionCondition.JSON_KEYS_COUNT:
            return isinstance(left, dict) and len(left.keys()) == int(right)
        if cond == AssertionCondition.JSON_ARRAY_LENGTH_EQUALS:
            return isinstance(left, list) and len(left) == int(right)
        if cond == AssertionCondition.JSON_ARRAY_CONTAINS:
            return isinstance(left, list) and right in left
        if cond == AssertionCondition.JSON_VALUE_EQUALS:
            # Expect right as [key, value]
            return isinstance(left, dict) and isinstance(right, (list, tuple)) and len(right) == 2 and left.get(str(right[0])) == right[1]
        raise ValueError(f"Unsupported condition: {cond}")

    # ---------- public API ----------
    def evaluate(self, variables: dict, get_variable_value: Callable, *args, **kwargs) -> (bool, dict):
        # Logical group node
        if self.operands:
            # If we have operands but no assertion_operands, check if we have a single operator
            if not self.assertion_operands:
                # Check if we have a single operator in assertion_operator (for backward compatibility)
                if len(self.assertion_operator) == 1 and isinstance(self.assertion_operator[0], ConcatenationOperator):
                    op = self.assertion_operator[0]
                else:
                    # Default to AND if no operator specified
                    op = ConcatenationOperator.AND
            else:
                # Use the first operator from assertion_operands
                op = self.assertion_operands[0]

            # fold with the operator between children
            result, used_variables = self.operands[0].evaluate(variables, get_variable_value, *args, **kwargs)
            for idx in range(1, len(self.operands)):
                val, child_variables = self.operands[idx].evaluate(variables, get_variable_value, *args, **kwargs)
                used_variables.update(child_variables)
                if op == ConcatenationOperator.AND:
                    result = result and val
                elif op == ConcatenationOperator.OR:
                    result = result or val
                else:
                    raise ValueError(f"Unsupported logical operator: {op}")
            return result, used_variables

        # Leaf comparison node: all listed conditions must hold (logical AND)
        left, left_variables = self._resolve(self.left_operand, variables, get_variable_value, *args, **kwargs)
        right, right_variables = self._resolve(self.right_operand, variables, get_variable_value, *args, **kwargs)
        # Combine all used variables
        used_variables = {}
        used_variables.update(left_variables)
        used_variables.update(right_variables)
        
        for cond in self.assertion_operator:
            if not self._eval_leaf_condition(cond, left, right):
                return False, used_variables
        return True, used_variables

    def to_dict(self) -> dict:
        return {
            "operator": [op.value for op in self.assertion_operator],
            "assertion_operands": [op.value for op in self.assertion_operands],
            "left_operand": self.left_operand,
            "right_operand": self.right_operand,
            "operands": [child.to_dict() for child in self.operands] if self.operands else []
        }

    
    @classmethod
    def from_json(cls, json_data: dict) -> "Assertion":
        # Check if this is a logical group by looking at assertion_operands first (new format)
        assertion_operands = json_data.get("assertion_operands", [])
        if assertion_operands and assertion_operands[0] in ConcatenationOperator._value2member_map_:
            # This is a logical group (new format)
            concat = ConcatenationOperator(assertion_operands[0])
            children = [cls.from_json(o) for o in json_data.get("operands", [])]
            return cls(
                assertion_operator=[],
                assertion_operands=[concat],
                operands=children
            )
        
        # Check if this is a logical group by looking at operator field (old format)
        op_data = json_data.get("operator", [])
        if isinstance(op_data, str) and op_data in ConcatenationOperator._value2member_map_:
            # This is a logical group (old format)
            concat = ConcatenationOperator(op_data)
            children = [cls.from_json(o) for o in json_data.get("operands", [])]
            return cls(
                assertion_operator=[],
                assertion_operands=[concat],
                operands=children
            )
        
        # Handle leaf nodes - both single operator string and list of operators
        if isinstance(op_data, list):
            conditions = [AssertionCondition(op) for op in op_data] if op_data else [AssertionCondition.EQUALS]
        else:
            conditions = [AssertionCondition(op_data)] if op_data else [AssertionCondition.EQUALS]
            
        return cls(
            assertion_operator=conditions,
            left_operand=json_data.get("left_operand"),
            right_operand=json_data.get("right_operand")
        )