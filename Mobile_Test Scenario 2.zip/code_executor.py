# code_executor.py
"""
CodeExecutor - single-file implementation.

Notes:
- Node sandbox runs single generated JS file (no separate checked-in runner).
- User JS and predefs are base64-encoded before embedding to avoid injection.
- Node uses isolated-vm to create an Isolate and Context; user code runs inside the isolate.
- The isolate-side wrapper returns a JSON string; Python parses the marker line.
- Ensure `node` is on PATH and `npm install isolated-vm` was performed where node runs.
"""

import ast
import asyncio
import base64
import json
import os
import pickle
import re
import signal
import subprocess
import sys
import tempfile
import pathlib
import textwrap
from typing import Any, Dict, Optional, Union
from enum import Enum
import traceback

try:
    from selenium import webdriver
    from appium.webdriver.webdriver import WebDriver
except ImportError:
    pass


class ScriptExecutionMode(Enum):
    DRIVER = "driver"
    LAMBDA_HOOK = "lambda_hook"
    SANDBOX = "sandbox"


class ScriptExecutionModeParams:
    mode: ScriptExecutionMode
    node_sandbox_runtime_path: str
    node_sandbox_runtime_env: Optional[Dict[str, Any]]

    def __init__(self, params: Dict[str, Any]={}):
        self.mode = ScriptExecutionMode(params.get('mode', "driver"))
        self.node_sandbox_runtime_path = params.get('node_sandbox_runtime_path', '') #will point to node binary path
        self.node_sandbox_runtime_env = params.get('node_sandbox_runtime_env', None) #will point to node environment variables

    def to_dict(self) -> Dict[str, Any]:
        return {
            "mode": self.mode.value,
            "node_sandbox_runtime_path": self.node_sandbox_runtime_path,
            "node_sandbox_runtime_env": self.node_sandbox_runtime_env
        }


class _CodeExecutorType(Enum):
    JAVASCRIPT = "javascript"
    PYTHON = "python"


class CodeExecutionResponse:
    value: Any
    error: str
    line: Optional[int]
    timed_out: bool
    exit_code: int

    def __init__(self, value: Any = '', error: str = '', line: Optional[int] = None, timed_out: bool = False, exit_code: int = 0):
        self.value = value
        self.error = error
        self.line = line
        self.timed_out = timed_out
        self.exit_code = exit_code

    def to_dict(self) -> Dict[str, Any]:
        return {
            "value": self.value,
            "error": self.error,
            "line": self.line,
            "timed_out": self.timed_out,
            "exit_code": self.exit_code
        }


class CodeExecutor:
    
    def __init__(self, driver: Optional[Union[webdriver.Chrome, 'WebDriver']], script_type: str, code_snippet: str, predefs: Optional[Dict[str, Any]] = None, timeout_sec: Optional[int] = None, execution_mode_params: Optional[Dict[str, Any]] = {}):
        """
        :param driver: selenium webdriver instance
        :param script_type: type of script to execute
        :param code_snippet: user code script
        :param predefs: vars dict if any
        :param timeout_sec: timeout for the subprocess to run
        :param execution_mode: mode of execution
        """
        self.driver = driver
        self.script_type = _CodeExecutorType(script_type)
        self.code_snippet = code_snippet
        self.predefs = predefs if predefs else {}
        self.timeout_sec = timeout_sec
        self.execution_mode_params = ScriptExecutionModeParams(execution_mode_params) if execution_mode_params else ScriptExecutionModeParams({"mode": "driver"})

        if self.execution_mode_params.mode != ScriptExecutionMode.SANDBOX and not self.driver:
            raise ValueError("Driver is required for execution mode: driver")

    
    def execute_sync(self, lambda_hook_args: Optional[Dict[str, Any]] = {}) -> Dict[str, Any]:
        # lambda hook mode is independent of the script type and executor instance
        try:
            if self.execution_mode_params.mode == ScriptExecutionMode.LAMBDA_HOOK:
                execution_response = self._execute_via_lambda_hook(lambda_hook_args)
            else:
                executor_instance = self.get_executor_instance()
                execution_response = executor_instance.execute()
            return execution_response.to_dict()
        except Exception as e:
            return CodeExecutionResponse(error=str(e)).to_dict()


    async def execute_async(self, lambda_hook_args: Optional[Dict[str, Any]] = {}) -> Dict[str, Any]:
        loop = asyncio.get_event_loop()
        execution_response = await loop.run_in_executor(None, self.execute_sync, lambda_hook_args)
        return execution_response

    
    def get_executor_instance(self):
        if self.script_type == _CodeExecutorType.JAVASCRIPT:
            return JavaScriptCodeExecutor(self.driver, self.code_snippet, self.execution_mode_params, self.predefs, self.timeout_sec)
        elif self.script_type == _CodeExecutorType.PYTHON:
            return PythonCodeExecutor(self.code_snippet, self.predefs, self.timeout_sec)
        else:
            raise ValueError(f"Invalid script type: {self.script_type}")


    def _execute_via_lambda_hook(self, lambda_hook_args: Optional[Dict[str, Any]] = {}) -> CodeExecutionResponse:
        '''
        Execute the script via the lambda hook support. This is invoked for Mobile App tests during test execution via Hyperexecute
        '''
        args = {
                "command": "executeScript",
                "driverSessionId":  self.driver.session_id,
                "testId": os.getenv('TEST_ID', '') or self.driver.session_id,
                "commitId": os.getenv('COMMIT_ID', ''),
                "org_id": int(os.getenv('ORG_ID', '0')),
                "payload": {}
            }

        if lambda_hook_args:
            args["payload"].update(lambda_hook_args)

        args["payload"].update({
            "code_snippet": self.code_snippet,
            "script_type": self.script_type.value,
            "variables": self.predefs,
            "timeout_sec": self.timeout_sec
        })

        response: dict = self.driver.execute_script("lambda-kane-ai", args)

        if not response or not isinstance(response, dict):
            return CodeExecutionResponse(error=f"Invalid response from lambda hook: {response}")

        # transform to _CodeExecutionResponse
        return CodeExecutionResponse(value=response.get('value', ''), error=response.get('error', ''), line=response.get('line', None), timed_out=response.get('timed_out', False), exit_code=response.get('exit_code', 0))
        
        

class JavaScriptCodeExecutor:
    """
    Class to orchestrate execution of user javascript snippets in a subprocess.
    """
    DEFAULT_TIMEOUT = 10

    def __init__(self, driver: Optional[Union[webdriver.Chrome, 'WebDriver']], code_snippet: str, execution_mode_params: ScriptExecutionModeParams, predefs: Optional[Dict[str, Any]], timeout_sec: Optional[int]):
        """
        :param driver: selenium webdriver instance
        :param code_snippet: user code script
        :param predefs: vars dict if any
        :param timeout_sec: timeout for the subprocess to run
        :param execution_mode: mode of execution
        """
        self.driver = driver
        self.code_snippet = code_snippet
        self.predefs = predefs if predefs else {}
        self.timeout_sec = timeout_sec or self.DEFAULT_TIMEOUT
        self.execution_mode_params = execution_mode_params


    def _wrap_in_response_template(self, script: str) -> str:
        script += "\n"
        lines_before_user_code = 2
        return f"""
            return (function() {{
                try {{
                    return (function() {{
                        {script}
                    }})();
                }} catch (e) {{
                    e.stack = e.stack.replace(/<anonymous>:(\\d+):/g, function(match, lineNumber) {{
                        lineNumber = parseInt(lineNumber) - {lines_before_user_code};
                        return '<anonymous>:' + lineNumber + ':';
                    }});
                    return {{ error: e.stack }};
                }}
            }})();"""  


    def _inject_variables(self, script: str, variables: Dict[str, Any]) -> str:
        # backward compatibility check for clearing variables in script
        pattern = r'//Variables start.*?//Variables end\n*'
        find_variables = re.findall(pattern, script, re.DOTALL)
        sanitised_script = script
        if find_variables:
            sanitised_script = script.replace(find_variables[0], "")

        updated_script = ""
        updated_variables = ""
        for key, value in variables.items():
            js_val = json.dumps(value, ensure_ascii=False)
            updated_variables += f"const {key} = {js_val};\n"
        updated_script = f"//Variable definitions\n{updated_variables}\n\n{sanitised_script}"
        return updated_script

    
    def _clean_variables_from_script(self, script: str) -> str:
        pattern = r'//Variables start.*?//Variables end\n*'
        find_variables = re.findall(pattern, script, re.DOTALL)
        if find_variables:
            return script.replace(find_variables[0], '')
        return script


    def _contains_imports(self, script: str) -> bool:
        _JS_IMPORT_RE = re.compile(r'^\s*(?:import\s.+|(?:const|let|var)\s+\w+\s*=\s*require\(.+\))\s*;?\s*$', re.MULTILINE)
        matches = _JS_IMPORT_RE.search(script)
        return matches is not None and len(matches.group(0)) > 0


    def _validate(self) -> tuple[bool, CodeExecutionResponse]:
        forbidden_js_functions = ["tagifyWebpage", "removeLTTags", "startEventsCapture", "stopEventsCapture", "captureEventDetails"]
        lines = self.code_snippet.splitlines()
        for line_number, line in enumerate(lines, start=1):
            for forbidden in forbidden_js_functions:
                if forbidden in line:
                    return (False, CodeExecutionResponse(error=f"The script contains forbidden function '{forbidden}'", line=line_number))
        
        if self._contains_imports(self.code_snippet):
            return (False, CodeExecutionResponse(error="External imports are not allowed in the script"))

        return (True, CodeExecutionResponse())


    def post_process_response_value(self, response: CodeExecutionResponse) -> CodeExecutionResponse:
        if not response or response.error:
            return response
        try:
            if response.value is None or response.value == '':
                response.value = "null"
            else:
                # Attempt to serialize the return value
                json.dumps(response.value)
                
        except:
            # If serialization fails, convert the return value to a string
            str_val = str(response.value)
            response.value = str_val

        return response


    
    def execute(self) -> CodeExecutionResponse:
        """
        Execute the script in requested execution mode
        """
        try:
            is_valid, validation_response = self._validate()
            if not is_valid:
                return validation_response
            execution_response = CodeExecutionResponse()
            match self.execution_mode_params.mode:
                case ScriptExecutionMode.DRIVER:
                    execution_response = self._execute_via_driver()
                case ScriptExecutionMode.SANDBOX:
                    execution_response = self._execute_via_node_sandbox()
            return self.post_process_response_value(execution_response)
        except Exception as e:
            return CodeExecutionResponse(error=str(e))
        
        
    def _execute_via_driver(self) -> CodeExecutionResponse:
        '''
        Execute the script via the driver method. This is invoked for KaneAI Web and Mobile Browser tests
        '''
        script_with_vars = self._inject_variables(self.code_snippet, self.predefs)
        script_with_response_template = self._wrap_in_response_template(script_with_vars)

        response = self.driver.execute_script(script_with_response_template)
        if isinstance(response, dict) and 'error' in response:
            # An error occurred during execution
            error_stack = response['error']
            lines = error_stack.split('\n')
            error_message = lines[0].strip()
            error_line = None
            
            # Extract the line number from the stack trace
            if len(lines) > 1:
                match = re.search(r'<anonymous>:(\d+):', lines[1])
                if match:
                    error_line = int(match.group(1))
            
            return CodeExecutionResponse(error=error_message, line=error_line)
        else:
           return CodeExecutionResponse(value=response)



    def _execute_via_node_sandbox(self) -> CodeExecutionResponse:
        '''
        Execute the script via the node sandbox support. This is invoked by KaneAI Agent for Mobile App tests
        '''
        script_without_vars = self._clean_variables_from_script(self.code_snippet) # remove vars as in sandbox env, need to inject vars as globals during runtime
        executor = NodeSandboxExecutor(self.execution_mode_params.node_sandbox_runtime_path, self.execution_mode_params.node_sandbox_runtime_env, self.timeout_sec)
        result = executor.execute(script_without_vars, self.predefs)
        return CodeExecutionResponse(value=result.get('value'), error=result.get('error', ''), line=result.get('line'), timed_out=result.get('timed_out', False), exit_code=result.get('exit_code', 0))



class NodeSandboxExecutor:
    """
    Executes JavaScript code in a Node.js subprocess with sandboxed environment.
    """
    
    def __init__(self, sandbox_runtime_path: str = 'node', sandbox_runtime_env: Optional[Dict[str, Any]] = None, timeout_sec: int = 5, memory_limit: int = 128):
        """
        Initialize the Node.js sandbox executor.
        
        :param sandbox_runtime_path: Path to Node.js executable
        :param timeout_sec: Timeout for subprocess execution
        """
        self.sandbox_runtime_path = sandbox_runtime_path
        self.sandbox_runtime_env = sandbox_runtime_env
        self.timeout_sec = timeout_sec
        self.output_marker = "__NODE_OUT__:"
        self.template_path = pathlib.Path(__file__).parent / "node_runner_template.js"
        self.memory_limit = memory_limit or 128
    
    def execute(self, script: str, predefs: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Execute JavaScript code in Node.js subprocess with sandboxed environment.
        
        :param script: JavaScript code to execute
        :param predefs: Variables to inject into the execution context
        :return: Dictionary with execution results
        """
        try:
            # Create Node.js script with sandboxed execution
            node_script = self._create_node_script(script, predefs or {}, self.output_marker, self.memory_limit)

            # Write to temporary file
            temp_script_path = ""
            with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as temp_file:
                temp_file.write(node_script)
                temp_script_path = temp_file.name
            
            try:
                # Execute Node.js script
                result = self._run_node_process(temp_script_path)
                return result
            finally:
                # Clean up temporary file
                try:
                    os.unlink(temp_script_path)
                except Exception:
                    pass
                    
        except Exception as e:
            return {
                'success': False,
                'value': None,
                'error': f"Failed to execute Node.js sandbox: {str(e)}",
                'line': None,
                'timed_out': False,
                'exit_code': 1
            }

    def _create_node_script(self, user_code: str, predefs: Dict[str, Any], output_marker: str, memory_limit: int) -> str:
        """
        Build JS by substituting placeholders in the base64-enabled node_runner_template.js.

        - user_code: raw JS; will be base64-encoded into __USER_CODE_B64__
        - variables: dict; JSON-dumped then base64-encoded into __VARS_B64__
        - output_marker: e.g. "__NODE_OUT__:"
        - memory_limit: MB for isolate
        """
        tmpl_path = self.template_path
        if not tmpl_path.exists():
            raise FileNotFoundError(f"Template not found: {tmpl_path}")

        tmpl = tmpl_path.read_text(encoding="utf-8")

        # Encode payloads
        user_code_b64 = base64.b64encode(user_code.encode("utf-8")).decode("ascii")
        variables = predefs if predefs else {}
        vars_json = json.dumps(variables, ensure_ascii=False)
        vars_b64 = base64.b64encode(vars_json.encode("utf-8")).decode("ascii")

        # JS literals for simple types
        marker_literal = json.dumps(output_marker)  # quote as JS string
        mem_literal = str(int(memory_limit))       # numeric literal
        user_code_b64_literal = json.dumps(user_code_b64)
        vars_b64_literal = json.dumps(vars_b64)

        # Substitute placeholders
        final = (
            tmpl.replace("__USER_CODE_B64__", user_code_b64_literal)
                .replace("__VARS_B64__", vars_b64_literal)
                .replace("__MARKER__", marker_literal)
                .replace("__MEMORY_LIMIT__", mem_literal)
        )

        return final

    
    def _run_node_process(self, script_path: str) -> Dict[str, Any]:
        """
        Run Node.js process and parse the output.
        
        :param script_path: Path to the Node.js script file
        :return: Parsed execution result
        """
        cmd = [self.sandbox_runtime_path, script_path]
        print(f"Running Node.js process: runtime_path: [{self.sandbox_runtime_path}], runtime_env: [{self.sandbox_runtime_env}], script_path: [{script_path}]")
        
        # Check Node.js version and add NODE_OPTIONS if needed
        env = self.sandbox_runtime_env.copy() if self.sandbox_runtime_env else {}
        
        # check for node version and add --no-node-snapshot to NODE_OPTIONS if needed
        try:
            # Get Node.js version
            version_result = subprocess.run([self.sandbox_runtime_path, '--version'], 
                                          capture_output=True, text=True, timeout=5)
            if version_result.returncode == 0:
                version_output = version_result.stdout.strip()
                # Extract version number (e.g., "v20.1.0" -> 20)
                version_match = re.search(r'v(\d+)\.', version_output)
                if version_match:
                    major_version = int(version_match.group(1))
                    if major_version >= 20:
                        # Add --no-node-snapshot to NODE_OPTIONS if not already present
                        node_options = env.get('NODE_OPTIONS', '')
                        if '--no-node-snapshot' not in node_options:
                            if node_options:
                                env['NODE_OPTIONS'] = f"{node_options} --no-node-snapshot"
                            else:
                                env['NODE_OPTIONS'] = "--no-node-snapshot"
        except:
            print(f"Warning: Could not check Node.js version: {traceback.format_exc()}")
        
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            start_new_session=True,
            env=env
        )
        
        timed_out = False
        try:
            stdout, stderr = proc.communicate(timeout=self.timeout_sec)
        except subprocess.TimeoutExpired:
            timed_out = True
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except Exception:
                pass
            try:
                stdout, stderr = proc.communicate(timeout=1)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except Exception:
                    pass
                stdout, stderr = "", "killed after timeout"
        
        exit_code = proc.returncode if not timed_out else -9
        
        # Parse the JSON response from stdout
        if stdout.strip():
            # Look for the marker line
            lines = [ln for ln in stdout.splitlines() if ln.startswith(self.output_marker)]
            if lines:
                last = lines[-1]  # Take the last marker line
                try:
                    response_data = json.loads(last[len(self.output_marker):])
                    return {
                        'success': response_data.get('success', False),
                        'value': response_data.get('value'),
                        'error': response_data.get('error', ''),
                        'line': response_data.get('line'),
                        'timed_out': timed_out,
                        'exit_code': exit_code
                    }
                except json.JSONDecodeError:
                    return {
                        'success': False,
                        'value': None,
                        'error': f"Failed to parse Node.js response: {last}",
                        'line': None,
                        'timed_out': timed_out,
                        'exit_code': exit_code
                    }
            else:
                return {
                    'success': False,
                    'value': None,
                    'error': f"No output marker found in Node.js response: {stdout}",
                    'line': None,
                    'timed_out': timed_out,
                    'exit_code': exit_code
                }
        else:
            return {
                'success': False,
                'value': None,
                'error': f"Node.js execution failed: {stderr}",
                'line': None,
                'timed_out': timed_out,
                'exit_code': exit_code
            }
            



class PythonCodeExecutor:
    """
    Class to orchestrate execution of user python snippets in a subprocess.
    """

    MARKER = "__PY_OUT__:"
    DEFAULT_TIMEOUT = 10
    CODE_INDENT = " " * 4

    def __init__(self, code_snippet: str, predefs: Optional[Dict[str, Any]] = None, timeout_sec: Optional[int] = None):
        """
        :param code_snippet: user code script
        :param predefs: vars dict if any
        :param timeout_sec: timeout for the subprocess to run
        """
        self.code_snippet = code_snippet #user code script
        self.predefs = predefs if predefs else {}  #vars dict if any
        self.timeout_sec = timeout_sec or self.DEFAULT_TIMEOUT #timeout for the subprocess to run
        self.template_path = pathlib.Path(__file__).parent / "python_runner_template.py"

    def _get_executor_template(self):
        tmpl_path = self.template_path
        if not tmpl_path.exists():
            raise FileNotFoundError(f"Template not found: {tmpl_path}")

        tmpl = tmpl_path.read_text(encoding="utf-8")
        return tmpl

        
    # -------------------------
    # AST import stripper
    # -------------------------
    def _strip_imports_ast(self, source: str) -> str:
        """
        Remove Import and ImportFrom nodes using AST. Prefer ast.unparse when available.
        Falls back to conservative regex removal if necessary.
        """
        try:
            tree = ast.parse(source)
            new_body = [node for node in tree.body if not isinstance(node, (ast.Import, ast.ImportFrom))]
            tree.body = new_body
            try:
                source2 = ast.unparse(tree)
            except AttributeError:
                # fallback to regex
                raise
            return source2
        except Exception:
            import_re = re.compile(r'^\s*(from\s+\S+\s+import\s+.+|import\s+.+)$', re.MULTILINE)
            return re.sub(import_re, '# <import-stripped>', source)

    # -------------------------
    # Predefs: write pickle (no validation)
    # -------------------------
    def _write_predefs_pickle(self, predefs: Dict[str, Any], target_dir: str) -> str:
        path = os.path.join(target_dir, "predefs.pickle")
        with open(path, "wb") as f:
            pickle.dump(predefs, f, protocol=pickle.HIGHEST_PROTOCOL)
        return path

    # -------------------------
    # Subprocess runner
    # -------------------------
    def _run_subprocess(self, code_runner_path: str, predefs_pickle_path: str, timeout_sec: int):
        proc = subprocess.Popen([sys.executable, code_runner_path, predefs_pickle_path],
                                cwd=os.path.dirname(code_runner_path),
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                text=True, start_new_session=True)
        timed_out = False
        try:
            out, err = proc.communicate(timeout=timeout_sec)
        except subprocess.TimeoutExpired:
            timed_out = True
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except Exception:
                pass
            try:
                out, err = proc.communicate(timeout=1)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except Exception:
                    pass
                out, err = "", "killed after timeout"
        exit_code = proc.returncode if not timed_out else -9
        return out, err, timed_out, exit_code

    # -------------------------
    # Public API
    # -------------------------
    def execute(self) -> CodeExecutionResponse:
        """
        execute the python script
        """
        timeout_sec = self.timeout_sec

        # 1) normalize and strip imports
        raw = self.code_snippet
        if raw and not raw.endswith("\n"):
            raw += "\n"
        cleaned = self._strip_imports_ast(raw)

        # 2) ensure child template exists
        template_text = self._get_executor_template()

        # 3) inject cleaned user code into template
        injected = template_text.replace("# <<USER_CODE>>", textwrap.indent(cleaned, self.CODE_INDENT)) # may need to check for indentation here

        # 4) create temp dir, write code_runner.py and predefs pickle
        with tempfile.TemporaryDirectory(prefix="user_exec_") as td:
            code_runner_path = os.path.join(td, "code_runner.py")
            with open(code_runner_path, "w", encoding="utf-8") as f:
                f.write(injected)

            try:
                predefs_path = self._write_predefs_pickle(self.predefs, td)
            except Exception as e:
                return CodeExecutionResponse(error=f"Error writing predefs pickle: {str(e)}")

            # 5) run subprocess
            out, err, timed_out, exit_code = self._run_subprocess(code_runner_path, predefs_path, timeout_sec)

            # 6) parse last marker line
            parsed = None
            if out:
                lines = [ln for ln in out.splitlines() if ln.startswith(self.MARKER)]
                if lines:
                    last = lines[-1]
                    try:
                        parsed = json.loads(last[len(self.MARKER):])
                    except Exception:
                        err = f"Invalid marker JSON: {last}"

            return CodeExecutionResponse(value=parsed, error=err, timed_out=timed_out, exit_code=exit_code)
